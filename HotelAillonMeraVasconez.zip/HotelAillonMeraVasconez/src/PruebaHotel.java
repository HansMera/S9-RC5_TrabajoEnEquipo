import hotel.Hotel;
import hotel.Reserva;
import hotel.Habitación;
import java.util.Scanner;
public class PruebaHotel {
    public static void main(String[] args) {
        String nombre;
        int cedula;
        int metodoPago;
        int numNoches;

        Scanner sc = new Scanner(System.in);
        Hotel h = new Hotel();
        System.out.println("bienvenido trabajdor del hotel "+ h.getNombre());
        System.out.println("Que deseas hacer?\nSalir: 0\nRegistrar una reserva: 1\nBuscar una reserva: 2\nEliminar una reserva: 3");
        int opcion = sc.nextInt();
        sc.nextLine();
        do {
            switch (opcion) {
                case 1:
                    System.out.print("Por favor ayudenos con el nombre de la persona que va a reservar: ");
                    nombre = sc.nextLine();
                    if (h.buscarHabitacionPorNombre(nombre) != null) {
                        System.out.println("el nombre ya existe");
                        break;
                    }
                    System.out.print("Por favor ingrese el numero de cedula: ");
                    cedula = sc.nextInt();
                    System.out.print("por favor ingrese el metodo de pago:\n1: tarjeta\n2: cash\n3: tranferencia\nrespuesta numerica: ");
                    metodoPago = sc.nextInt();
                    System.out.print("ingrese el numero de noches que se piensa quedar: ");
                    numNoches = sc.nextInt();
                    if (h.reservaHabitacion(numNoches, nombre, cedula, metodoPago)) {
                        System.out.println("reserva resliazada con exito");
                    } else {
                        System.out.println("no se puede reservar");
                    }
                    break;
                case 2:
                    sc.nextLine(); // limpiar buffer
                    System.out.print("Por favor ayúdenos con el nombre de la persona: ");
                    nombre = sc.nextLine();
                    Habitación habitacionEncontrada = h.buscarHabitacionPorNombre(nombre);
                    if (habitacionEncontrada == null) {
                        System.out.println("El nombre no existe");
                    }
                    break;
                case 3:
                    sc.nextLine(); // limpiar buffer
                    System.out.print("Por favor ayúdenos con el nombre de la persona: ");
                    nombre = sc.nextLine();
                    h.eliminarReserva(nombre);
                    break;



            }
            System.out.println("Que deseas hacer?\nSalir: 0\nRegistrar una reserva: 1\nBuscar una reserva: 2\nEliminar una reserva: 3");
            opcion = sc.nextInt();
            sc.nextLine();
        }while (opcion != 0);

    }
}
