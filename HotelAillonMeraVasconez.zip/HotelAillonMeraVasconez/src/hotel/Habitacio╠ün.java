package hotel;

public class Habitación {
    private Reserva infoReserva = new Reserva(null,0,0);
    private double precio;
    private boolean reserva;
    private int numNoches;
    private double total;

    public Habitación() {
        this.infoReserva = new Reserva("", 0, 1); // por defecto
        this.precio = 50;
        this.reserva = false;
        this.numNoches = 0;
        setTotal();
    }

    public Reserva getInfoReserva() {
        return infoReserva;
    }


    public boolean isReserva() {
        return reserva;
    }
    public int getNumNoches() {
        return numNoches;
    }
    public double getTotal() {
        return total;
    }
    public void setNumNoches(int numNoches) {
        this.numNoches = numNoches;
    }
    public void setTotal () {
        this.total = this.precio* this.numNoches;
    }
    public void setReserva(boolean reserva) {
        this.reserva = reserva;
    }

    public boolean reservar(){
        if (!reserva) {
            reserva = true;
            return true;
        } else {
            return false;
        }
    }
    public boolean reservarReserva(int numNoches, String nombre, int cedula, int metodoPago){
            if (infoReserva.getNombre() != null) {
                infoReserva.reservar(nombre, cedula, metodoPago);
                setNumNoches(numNoches);
                setTotal();
                return true;
            } else {
                return false;
            }
    }



}
