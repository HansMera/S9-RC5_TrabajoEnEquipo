package hotel;

public class Hotel {
    private static int NUMH =100;
    private static String NOMBRE = "Hotel el Mariano";
    private int cantHabitaciones;

    private Habitación habitaciones[];

    public Hotel() {
        habitaciones = new Habitación[NUMH];
        for (int i = 0; i < NUMH; i++) {
            habitaciones[i] = new Habitación(); // ✔️ Ahora sí tiene reserva válida
        }
    }


    public void getHabitaciones() {
        for (int i = 0; i < NUMH; i++) {
            System.out.println(habitaciones[i]);
        }
    }

    public String getNombre (){
        return NOMBRE;
    }

    public Habitación buscarHabitacionPorNombre (String nombre){
        int index = 0;
        Reserva reserva = null;
        while (index < NUMH){
            Reserva res = habitaciones[index].getInfoReserva();
            if (res != null && res.getNombre() != null && res.getNombre().equals(nombre)) {
                reserva = habitaciones[index].getInfoReserva();
                System.out.println("--------------------------------------------------------------");
                System.out.println("info reserva: " + reserva.getNombre() + "\ncedula: " + reserva.getCedula()
                                    + "\nMetodo de pago: "+reserva.getMetodoPago() + "\nhabitación: " + (index+1)
                                    + "\nnumero de noches: "+ habitaciones[index].getNumNoches()
                                    + "\ntotal a pagar: " + habitaciones[index].getTotal());
                System.out.println("--------------------------------------------------------------");
                return habitaciones[index];
            }else{
                index++;
            }
        }
        return null;
    }

    public boolean reservaHabitacion (int numNoches,String nombre, int cedula, int metodoPago){
        int index = 0;
        while (index < NUMH){
            if (habitaciones[index].isReserva() == false){
                habitaciones[index].reservar();
                habitaciones[index].reservarReserva(numNoches,nombre,cedula,metodoPago);
                System.out.println("--------------------------------------------------------------");
                System.out.println("reserva en el cuarto numero: "+ (index+1));
                System.out.println("--------------------------------------------------------------");
                return true;
            }else{
                index++;
            }
        }
        return false;
    }

    public void eliminarReserva (String nombre ){
        if(buscarHabitacionPorNombre(nombre)!=null){
            Habitación habitacion = buscarHabitacionPorNombre(nombre);
            habitacion.setNumNoches(0);
            habitacion.getInfoReserva().setCedula(1);
            habitacion.getInfoReserva().setNombre(" ");
            habitacion.setTotal();
            habitacion.setReserva(false);
            System.out.println("--------------------------------------------------------------");
            System.out.println("RESERVA ELIMINADA");
            System.out.println("--------------------------------------------------------------");
        }
    }



}
