package hotel;


public class Reserva {
    private String nombre=null;
    private int cedula=0;
    private String metodoPago=null;

    public Reserva(String nombre, int cedula, int metodoPago) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.metodoPago = setMetodoPago(metodoPago);
    }

    public String getNombre() {
        return nombre;
    }

    public int getCedula() {
        return cedula;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCedula(int cedula) {
        if (cedula > 0) {
            this.cedula = cedula;
        } else {
            System.out.println("Cédula inválida.");
        }
    }

    public String setMetodoPago(int opc) {
        if (opc ==1){
            return this.metodoPago = "tarjeta";

        }else if (opc ==2){
            return this.metodoPago = "cash";

        }else if (opc ==3) {
            return this.metodoPago = "transferencia";

        }else{
            System.out.println("Error");
            return null;
        }
    }

    public void reservar(String nombre, int cedula, int opcMetodo){
        setNombre(nombre);
        setCedula(cedula);
        setMetodoPago(opcMetodo);
    }

    @Override
    public String toString() {
        return "Reserva" + "\nnombre=" + nombre + "\ncedula=" + cedula + "\nMetodo de Pago" +metodoPago;
    }



}
